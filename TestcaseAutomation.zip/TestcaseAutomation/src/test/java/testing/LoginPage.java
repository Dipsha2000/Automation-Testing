package testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginPage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\M1082620\\Downloads\\chromedriver_win32\\chromedriver.exe");
		
       	WebDriver driver = new ChromeDriver();
       	
       	driver.get("https://tide.com/en-us");
		
		driver.manage().window().maximize();
       	driver.findElement(By.xpath("//*[@id=\"site-header\"]/div[1]/div/div/div/div[2]/span/a")).click();
		driver.findElement(By.xpath("//*[@id=\"site-content\"]/div/div/div/div/div[1]/div/div/div/div[2]/div/p[6]/a")).click();
		
		String ParentWindowHandle=driver.getWindowHandle();
        for(String childnext:driver.getWindowHandles()) {
        driver.switchTo().window(childnext);
        }
       
        driver.findElement(By.xpath("//*[@id=\"scroll\"]/div/div/div/div/div[2]/form/div[7]/div/button")).click();
       //not working from here on
        driver.findElement(By.xpath("//input[@id=\"login-email\"]")).sendKeys("dipshaghosh007@gmail.com");
        driver.findElement(By.id("//*[@id=\"login-password\"]")).sendKeys("Diko@1507");
        driver.findElement(By.xpath("//*[@id=\"content\"]/main/div/div[2]/div/div[3]/div[2]/div/form/div[5]/div[1]/input")).click();
        
        driver.findElement(By.xpath("//*[@id=\"form-input\"]")).sendKeys("741101");
        driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[3]/div/div/div/div[2]/div/div[3]/div/div[2]/div/div/div/form/div[2]/div/div/div/button")).click();
        driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[3]/div/div/div/div[2]/div/div[3]/div/div[2]/div/div/div/form/div[2]/div/div/div")).click();
        
        
       // driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[3]/div/div/div/div[2]/div/div[3]/div/div[2]/div/div/div/form/div[5]/div/input")).click();
	
	}

}
