package testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CreateAccount {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\M1082620\\Downloads\\chromedriver_win32\\chromedriver.exe");
		
       	WebDriver driver = new ChromeDriver();
       	driver.get("https://tide.com/en-us");
		
		driver.manage().window().maximize();
		
		driver.findElement(By.xpath("//*[@id=\"site-header\"]/div[1]/div/div/div/div[2]/span/a")).click();
		driver.findElement(By.xpath("//*[@id=\"site-content\"]/div/div/div/div/div[1]/div/div/div/div[2]/div/p[6]/a")).click();
		
		String ParentWindowHandle=driver.getWindowHandle();
        for(String childnext:driver.getWindowHandles()) {
        driver.switchTo().window(childnext);
        }
        
		driver.findElement(By.xpath("//*[@id=\"name\"]")).sendKeys("Disha");
		driver.findElement(By.xpath("//*[@id=\"email\"]")).sendKeys("dioghosh07@gmail.com");
		driver.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys("Diko@1507");
		driver.findElement(By.xpath("//input[@value='CREATE ACCOUNT']")).click();
		
		//Thread.sleep(3000);
		
	}

}
